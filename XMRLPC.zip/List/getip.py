import socket
import multiprocessing

def get_ip_address(domain):
    try:
        ip_address = socket.gethostbyname(domain)
        return domain, ip_address
    except socket.gaierror:
        return domain, None

def process_website(website):
    website, ip_address = get_ip_address(website)
    if ip_address:
        print("Alamat IP dari {} adalah: {}".format(website, ip_address))
        # Menyimpan alamat IP ke dalam file "ip_addresses.txt"
        with open("ip_addresses.txt", "a") as output_file:
            output_file.write("{}\n".format(ip_address))
    else:
        print("Tidak dapat menemukan alamat IP untuk domain {}".format(website))
    return website, ip_address

def main():
    file_name = raw_input("Masukkan nama file (misal: list_website.txt): ")

    try:
        with open(file_name, 'r') as file:
            websites = [line.strip() for line in file if line.strip()]
    except IOError:
        print("Gagal membuka file:", file_name)
        return

    num_processes = min(multiprocessing.cpu_count(), len(websites))

    pool = multiprocessing.Pool(processes=num_processes)
    results = pool.map(process_website, websites)
    pool.close()
    pool.join()

if __name__ == "__main__":
    main()