target = raw_input("List > ")
bagiper = raw_input("Bagiperline > ")
listf  = open(target,"r").read()
delim = 1
abc = 0
for i in listf.splitlines():
	name = str(delim)+".txt"
	wr = open(name, "a")
	if abc == int(bagiper):
		print(name+" | "+str(abc))
		abc = 0
		delim = delim + 1
	else:
		abc = abc + 1
		wr.write(i+"\n")
	wr.close()