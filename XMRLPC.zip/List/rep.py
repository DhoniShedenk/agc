import requests,time,re,random,os,sys,json
from random import sample
from multiprocessing.dummy import Pool as ThreadPool
from colorama import Fore,Style, init
import subprocess
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
reload(sys)  
sys.setdefaultencoding('utf8')
init(autoreset=True)

r = Fore.RED + Style.BRIGHT
g = Fore.GREEN + Style.BRIGHT
c = Fore.CYAN + Style.BRIGHT
y = Fore.YELLOW + Style.BRIGHT
o = Fore.RESET + Style.RESET_ALL
def Banner():
    clear = '\x1b[0m'
    colors = [36, 32, 34, 35, 31, 37]

    x = '''

         .-"-.
       _/.-.-.\_
      ( ( o o ) )
       |/  "  \|     
        \ .-. /
        /`"""`\\
       /       \  
===========================
[ REVTOD V.1 | by Noniod7 ]
1. REVTOD 4 API
2. Delete Duplicate Domain
'''
    for N, line in enumerate(x.split('\n')):
        sys.stdout.write('\x1b[1;%dm%s%s\n' % (random.choice(colors), line, clear))
        time.sleep(0.05)
Banner()

pilihmas = raw_input(':~# \033[34mChoose\033[32m Number : ')


def rapid(url):
	try:
		headers = {
		'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36'
		}
		x = requests.get('https://rapiddns.io/sameip/'+url+'?full=1#result', headers=headers,timeout=30).content
		if '<th scope="row ">' in x:
			regex = re.findall('<td>(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z]{1,63}</td>', x)
			for jan in regex:
				cok = jan.replace('<td>','').replace('</td>','').replace('ftp.','').replace('images.','').replace('cpanel.','').replace('cpcalendars.','').replace('cpcontacts.','').replace('webmail.','').replace('webdisk.','').replace('hostmaster.','').replace('mail.','').replace('ns1.','').replace('ns2.','').replace('autodiscover.','').replace('.cdn.cloudflare.net','').replace('.cloudfront','')
				print("GET {} DOMAIN FROM {}".format(len(cok), url))
				open('revip.txt','a').write('http://'+cok+'\n')
			else:
				print("BAD RAP" + url )
	except:
		pass


def otxalienvault(url):
	try:
		API2 = 'https://otx.alienvault.com/otxapi/indicators/IPv4/passive_dns/'+url
		headers = {
		'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.141 Mobile Safari/537.36',
		}
		rev1 = requests.get(API2, headers=headers, timeout=30).content
		if 'hostname' in rev1:
			regex1 = re.findall('"hostname": "(.*?)"',rev1)
			for jan in regex1:
				res = jan.replace('<td>','').replace('</td>','').replace('ftp.','').replace('images.','').replace('cpanel.','').replace('cpcalendars.','').replace('cpcontacts.','').replace('webmail.','').replace('webdisk.','').replace('hostmaster.','').replace('mail.','').replace('ns1.','').replace('ns2.','').replace('autodiscover.','').replace('.cdn.cloudflare.net','').replace('.cloudfront','')
				print("GET {} DOMAIN FROM {}".format(len(res), url))
				open('revip.txt','a').write('http://'+res+'\n')
			else:
				print("BAD OTX" + url )
	except:
		pass

def atsameip(url):
	try:
		headers = {
		'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.141 Mobile Safari/537.36',
		}
		API = 'https://atsameip.intercode.ca/xmlloadIPpage2.php?threepointoneipnum=_216239032021&reverse_domain='+url+'&id_num=1'
		rev1 = requests.get(API,headers=headers, timeout=30).content
		reg = re.findall('(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z]{1,63}', rev1)
		for res in reg:
			print("GET {} DOMAIN FROM {}".format(len(res), url))
			open('revip.txt','a').write('http://'+res+'\n')
		else:
			print("BAD ATS" + url )
	except:
		pass


# delete duplicate

def DELETE_DUPLICATE():
    try:
        file = raw_input('LIST : ')
        SHINXX = open(file, 'r').read().splitlines()
        unique_domains = []
        seen_domains = set()
        
        for domain in SHINXX:
            if domain not in seen_domains:
                unique_domains.append(domain)
                seen_domains.add(domain)
                
        for domain in unique_domains:
            print(domain)

        with open(file + '.tmp', 'w') as new:
            new.write('\n'.join(unique_domains))
        
        os.remove(file)
        os.rename(file + '.tmp', file)
        print('DONE REMOVE DUPLICATE !!!')

    except Exception as e:
        print(e)
        pass

def ngentd(url):
	try:
		rapid(url)
		otxalienvault(url)
		atsameip(url)
	except:
		pass

def Main():
	try:
		if pilihmas == '1':
			url = open(raw_input('List:~# '),'r').read().splitlines()
			THREAD = raw_input('THREAD:~# ')
			pool = ThreadPool(int(THREAD))
			pool.map(ngentd, url)
			pool.close()
			pool.join()
		if pilihmas == '2':
			DELETE_DUPLICATE()
			
	except:
		pass
			
if __name__ == '__main__':
	Main()
	